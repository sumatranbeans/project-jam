# Wave 1 Files - Installation Instructions

## Step 1: Copy Files
Copy these files to your project:

- `lib/vault.ts` → `/workspaces/project-jam/lib/vault.ts`
- `app/vault-actions.ts` → `/workspaces/project-jam/app/vault-actions.ts`
- `app/page.tsx` → `/workspaces/project-jam/app/page.tsx` (REPLACE existing)
- `app/onboarding/page.tsx` → `/workspaces/project-jam/app/onboarding/page.tsx` (NEW folder)
- `app/settings/page.tsx` → `/workspaces/project-jam/app/settings/page.tsx` (NEW folder)

## Step 2: Install Dependencies
Run in terminal:
```bash
npm install @upstash/redis crypto-js && npm install -D @types/crypto-js
```

## Step 3: Add Environment Variables to Vercel
Go to Vercel → project-jam-sagv → Settings → Environment Variables

Add these (get from Upstash dashboard):
- `KV_REST_API_URL` = your Upstash Redis REST URL
- `KV_REST_API_TOKEN` = your Upstash Redis REST token

## Step 4: Push and Deploy
```bash
git add . && git commit -m "feat: Wave 1 - Key Vault + Onboarding" && git push
```

## What This Adds
- Encrypted API key storage (AES-256)
- Onboarding wizard for new users
- Settings page to manage keys
- Auto-redirect to onboarding if keys not set
